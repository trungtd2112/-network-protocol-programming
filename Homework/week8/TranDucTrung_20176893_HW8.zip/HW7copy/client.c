#include <netinet/in.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h> 
#include <sys/types.h> 
#include <arpa/inet.h> 
#include <errno.h> 
#include <signal.h> 
#include <strings.h> 
#include <sys/types.h> 
#include <unistd.h>

int check_new_password(char new_password[100]){
	for(int i = 0; i < strlen(new_password); i++){
		if((new_password[i] < '0' || new_password[i] > '9') && 
		(new_password[i] < 'A' || new_password[i] > 'Z') && 
		(new_password[i] < 'a' || new_password[i] > 'z'))
		{ 
			return 0;
		}
		
	}
	return 1;
}


int main(int argc, char *argv[]) 
{ 
	if (argc != 3){
		printf("Please input IP address and port number\n");		
		return 0;
	}
	char *ip_address = argv[1];
	int PORT = atoi(argv[2]);
	int sockfd; 
	struct sockaddr_in servaddr; 

	int n, len; 

	// Creating socket file descriptor 
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) { 
		printf("socket creation failed"); 
		exit(0); 
	} 

	memset(&servaddr, 0, sizeof(servaddr)); 

	// Filling server information 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_port = htons(PORT); 
	servaddr.sin_addr.s_addr = inet_addr(ip_address); 
	if(inet_pton(AF_INET, ip_address, &servaddr.sin_addr)<=0) 
	{ 
		printf("\nInvalid address/ Address not supported \n"); 
		return -1; 
	} 
	if (connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) < 0) { 
		printf("\n Error : Connect Failed \n"); 
	} 
	// ============================Start to communicate with Server======================
	// ==================================================================================
	do {
		int g= 0;
		int signed_in = 0;
		char buffer[100];
		char message[100];
		char username[100];
		char password[100];
		char new_password[100];
		printf("Username: ");
		g = scanf("%[^\n]", message); 
		if (g == 0) break;
		getchar();
		strcpy(username, message);


		send(sockfd , message , strlen(message) + 1, 0 ); 
		
		// waiting for response 
		recv(sockfd, buffer, sizeof(buffer), 0);
		if(strcmp(buffer, "username is OK") == 0){
			int wrong_password_count = 0;
			do{
				printf("Instert password: ");
				fgets(password, 100, stdin);
				password[strlen(password)-1]='\0';
				send(sockfd , password , strlen(password) + 1 , 0 ); 
				recv(sockfd, buffer, sizeof(buffer), 0);
				if (atoi(buffer) == 1){
			 		printf("OK\n");
					signed_in = 1;
					break;
				}else
				{
					printf("Not OK\n");
					wrong_password_count++;
				}
				
			}while(wrong_password_count < 3);
			if (wrong_password_count == 3){
				send(sockfd , "block" , strlen("block") + 1 , 0 ); 
				printf("Account is blocked\n");
			}
		}else if(strcmp(buffer, "Not exist") == 0)
		{
			printf("Wrong account\n");
		}else if(strcmp(buffer, "0") == 0)
		{
			printf("Account not ready\n");
		}
		puts("-------------------------------");
		if(signed_in == 1){
			puts("----------Signed in------------");
			do{
				printf("Enter \"bye\" to sign out. Another word to change password: ");
				fgets(new_password, 100, stdin);
				new_password[strlen(new_password)-1]='\0';
				if (check_new_password(new_password) != 0)
				{
					send(sockfd , new_password , strlen(new_password)+1 , 0 );
				} 
				if (strcmp("bye", new_password)== 0)
				{
					printf("Goodbye %s\n", username);
					puts("-------------------------------");
					signed_in = 0;
					break;
				}
				
				if (check_new_password(new_password) == 0)
				{
					printf("Error\n");
				}else
				{
					recv(sockfd, buffer, sizeof(buffer), 0);
					fprintf(stderr, buffer);
					fprintf(stderr, "\n");
				}
			}while (strcmp("bye", new_password) != 0);
		}
	}while(1);			
	return 0;
} 