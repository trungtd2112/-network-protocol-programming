//include library
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "./server_code/functions.h"       // code week 3

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// declare environment variable
#define BUFF_SIZE 100

#define NOT_LOGIN_STATUS 0
#define VALID_USERNAME_STATUS 1
#define LOGIN_STATUS 2
#define OK "1"
#define NOT_OK "0"


// declare global variable
int loginFailCount = 0, systemStatus = NOT_LOGIN_STATUS;
node* loginUser = NULL;

//-----------------------------------------------------------------------------------
void sendResponse(char *content, int sockfd, struct sockaddr *servaddr);
char* encrypt(char* plainText);

int main(int argc, char *argv[]){
    // check number of arguement
    if(argc != 2){
        printf("Lack/Abundance of parameters.\n");
        return -1;
    }

    // declare variables
    int portNumber, sockfd, rcvBytes, sendBytes, flag = 0;
    char buff[BUFF_SIZE+1], responseMsg[BUFF_SIZE]; 
    node* target = NULL;
    socklen_t len;
    struct sockaddr_in servaddr, cliaddr;


    // process
    portNumber = atoi(argv[1]);
    if(portNumber == 0){
        printf("Invalid port number./n");
        exit(-1);
    }
    // step 1: construct socket
    if((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
        perror("Error: Can't construct socket in server side.\n");
        return -1;
    } 

    // step 2: bind address to socket
    bzero(&servaddr, sizeof(servaddr));     // set address = 0.0.0.0
    servaddr.sin_family = AF_INET;          // set type of address
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY); 
    servaddr.sin_port = htons(portNumber);

    if(bind(sockfd, (struct sockaddr *) &servaddr, sizeof(servaddr))){
        perror("Error: Can't bind address to socket in server side.\n");
        return -1;
    }

    printf("Server started.\n");            // creating socket succeeded

    // step 3: initiate data with linked list
    node *head = initNode(&head); 
    readFile(&head);

    // step 4: communicate with client
    while(1){
        len = sizeof(cliaddr); 
        rcvBytes = recvfrom(sockfd, buff, BUFF_SIZE, 0, (struct sockaddr *) &cliaddr, &len);

        if(rcvBytes < 0){   
            perror("Error: Can't receive anything from client in server side.\n");
            return -1;
        }
        buff[rcvBytes] = '\0';
        
        fprintf(stderr,"[%s:%d]: %s\n", inet_ntoa(cliaddr.sin_addr), ntohs(cliaddr.sin_port), buff);
        
        if(buff[0] == '\0'){
            writeFile(head);
            freeList(head);
            exit(0);
        }
        else if(strcasecmp(buff,"bye") == 0){
            if(systemStatus == LOGIN_STATUS){
                responseMsg[0] = '\0';
                strcat(responseMsg, "Bye ");
                strcat(responseMsg, loginUser->user->username);
                sendResponse(responseMsg, sockfd, (struct sockaddr *) &cliaddr);

                loginUser = NULL;
                systemStatus = NOT_LOGIN_STATUS;
            }else{
                sendResponse("\"Bye\" is a keyword. You can not use it.", sockfd, (struct sockaddr *) &cliaddr);
            }
        }else{
            switch (systemStatus)
            {
            case NOT_LOGIN_STATUS:
                target = searchNode(buff, head);
                if(target == NULL){
                    sendResponse("Invalid username", sockfd, (struct sockaddr *) &cliaddr);
                }else{
                    sendResponse("Insert password", sockfd, (struct sockaddr *) &cliaddr);
                    loginUser = target;
                    systemStatus = VALID_USERNAME_STATUS;
                }       
                break;
            case VALID_USERNAME_STATUS:
                if(strcmp(loginUser->user->password, buff) == 0){
                    if(loginUser->user->isActive == 1){
                        sendResponse("OK", sockfd, (struct sockaddr *) &cliaddr);
                        systemStatus = LOGIN_STATUS;
                    }else{
                        sendResponse("Account not ready.", sockfd, (struct sockaddr *) &cliaddr);
                        systemStatus = NOT_LOGIN_STATUS;
                    }
                    loginFailCount = 0;
                }else{
                    loginFailCount++;
                    if(loginFailCount >= 3){
                        sendResponse("Account is blocked.", sockfd, (struct sockaddr *) &cliaddr);
                        loginFailCount = 0;   
                        loginUser->user->isActive = 0;
                        loginUser = NULL;
                        systemStatus = NOT_LOGIN_STATUS;
                    }else{
                        sendResponse("NOT_OK", sockfd, (struct sockaddr *) &cliaddr);
                    }
                }
                break;
            case LOGIN_STATUS:
                for(int i = 0; i < strlen(buff); i++){
                    if((buff[i] >= 'a' && buff[i] <= 'z') ||
                        (buff[i] >= 'A' && buff[i] <= 'Z' || 
                        (buff[i] >= '0' && buff[i] <= '9'))){

                        }else{
                            sendResponse("Invalid new password.", sockfd, (struct sockaddr *) &cliaddr);
                            flag = 1;          
                            break;  
                        }
                }
                if(flag == 1){
                    flag = 0;
                    break;
                }
                strcpy(loginUser->user->password, buff);
                responseMsg[0] = '\0';
                strcat(responseMsg, "Your new password: ");
                strcat(responseMsg, encrypt(loginUser->user->password));

                sendResponse(responseMsg, sockfd, (struct sockaddr *) &cliaddr);
                break;
            default:
                sendResponse("System is under maintenance.", sockfd, (struct sockaddr *) &cliaddr);    
                break;
            }  
        }      
    }        

    systemStatus = NOT_LOGIN_STATUS;

    return 0;
}

void sendResponse(char *content, int sockfd, struct sockaddr *servaddr){
    int len, sendBytes;
    
    len = sizeof(*servaddr);

    sendBytes = sendto(sockfd, content, strlen(content), 0, servaddr, len);
    
    if(sendBytes < 0){
        perror("Error: Can't send any data to server in client side.\n");
        exit(-1);
    }

}

char* encrypt(char* plainText){
    char encrypt[50];
    int count = 0;

    for(int i = 0; i < strlen(plainText); i++){
        // if((plainText[i] >= 'a' && plainText[i] <= 'z') || (plainText[i] >= 'A' && plainText[i] <= 'Z')){
        if(plainText[i] >= '0' && plainText[i] <= '9'){
            encrypt[count] = plainText[i]; 
            count++;       
        }
    }

    for(int i = 0; i < strlen(plainText); i++){
        if(plainText[i] < '0' || plainText[i] > '9'){
            encrypt[count] = plainText[i]; 
            count++;       
        }
    }

    encrypt[count] = '\0';
    printf("en:%s\n", encrypt);
    return strdup(encrypt);   
}