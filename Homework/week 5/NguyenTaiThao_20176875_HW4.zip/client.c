//include library
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// declare environment variable
#define BUFF_SIZE 100

#define NOT_LOGIN_STATUS 0
#define VALID_USERNAME_STATUS 1
#define LOGIN_STATUS 2
#define OK 1
#define NOT_OK 0

// declare global variable
int systemStatus = NOT_LOGIN_STATUS;
char loginUser[BUFF_SIZE], deviceId[BUFF_SIZE];


//---------------------------------------------------------------------------
char* sendRequest(char *content, int sockfd, struct sockaddr *servaddr);
char* setDeviceId();
//---------------------------------------------------------------------------

int main(int argc, char *argv[]){
    // check number of arguments
    if(argc != 3){
        printf("Lack/Abundance of parameters.\n");
        return -1;
    }

    strcpy(deviceId,setDeviceId());
    printf("Your device id: %s\n", deviceId);
    // declare variable
    int portNumberServer, sockfd, rcvBytes, sendBytes, countDot=0;
    socklen_t len;
    char buff[BUFF_SIZE+1],IPAddServer[15]; 
    struct sockaddr_in servaddr;

    // process
    strcpy(IPAddServer, argv[1]);
    portNumberServer = atoi(argv[2]);

    for (int i = 0; i < strlen(IPAddServer); i++) {
      if (IPAddServer[i] == '.') {
        countDot++;
      }
    }
    if (inet_addr(IPAddServer) == -1 || countDot != 3) {
      puts("Invalid IP address.\n");
      exit(-1);
    }

    if(portNumberServer == 0){
        printf("Invalid port number./n");
        exit(-1);
    }

    // step 1: construct socket
    if((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0){
        perror("Error: Can't construct socket in client side.\n");
        return -1;
    }

    //Step 2: Define the address of the server
    bzero(&servaddr, sizeof(servaddr)); 
    servaddr.sin_family = AF_INET; 
    inet_aton("127.0.0.1", &servaddr.sin_addr); 
    servaddr.sin_port = htons(portNumberServer); 

    //Step 3: Communicate with server
    while(1){
        char username[50], password[50], newPass[50];

        fgets(username, 50, stdin);
        username[strlen(username)-1] = '\0';
        
        strcpy(buff, sendRequest(username, sockfd, (struct sockaddr *) &servaddr));
        
        printf("%s\n", buff);
    }
    
    return 0;
}

char* sendRequest(char *content, int sockfd, struct sockaddr *servaddr){
    int len, sendBytes, rcvBytes;
    char buff[BUFF_SIZE];
    len = sizeof(*servaddr);
    sendBytes = sendto(sockfd, content, strlen(content), 0, servaddr, len);
    
    if(sendBytes < 0){
        perror("Error: Can't send any data to server in client side.\n");
        exit(-1);
    }

    if(content[0] == '\0'){
        exit(0);
    }

    rcvBytes = recvfrom(sockfd, buff, BUFF_SIZE, 0, servaddr, &len);

    if(rcvBytes < 0){
        perror("Error: Can't receive anything from server in client side.\n");
        exit(-1);
    }

    buff[rcvBytes] = '\0';
    return strdup(buff);
}

char* setDeviceId() {
    static const char alphanum[] =     "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    char s[20];
    for (int i = 0; i < 15; ++i) {
        s[i] = alphanum[rand() % (sizeof(alphanum) - 1)];
    }
    s[15] = 0;
    return strdup(s);
}