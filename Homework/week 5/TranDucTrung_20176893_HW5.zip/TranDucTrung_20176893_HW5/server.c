#include <unistd.h> 
#include <stdio.h> 
#include <sys/socket.h> 
#include <stdlib.h> 
#include <netinet/in.h> 
#include <string.h> 
#include<stdlib.h> 
#include <ctype.h>
#include <sys/types.h> 
#include <arpa/inet.h> 
#include <netdb.h>
#include <errno.h>

// =================================== LINKED LIST ========================================
// ========================================================================================
typedef struct 
{
	char user_name[20];
	char password[20];
	int status;
}elementtype;
#include "linkedlist.h"






void insertToList(singleList *list,elementtype element){
	// make null the list
	deleteSingleList(list);
	FILE *fp;
	fp = fopen("nguoidung.txt","r");
	// counting the length of this file
	char c;
	int count =0;
	for (c = getc(fp); c != EOF; c = getc(fp)) 
	{
        if (c == '\n') // Increment count if this character is newline 
            count = count + 1; 
	}
	fclose(fp);
	// read the data to list 
	fp = fopen("nguoidung.txt","r");
	for(int i=0;i< count + 1;i++){
		fscanf(fp, "%s %s %d", element.user_name, element.password, &element.status);
		insertEnd(list,element);
	}  
	fclose(fp);
}
int findInfo(singleList list, char username[20])  
{  
    list.cur = list.root; // Initialize current  
    // search all list to find username
    // if existed , return 1
    // else return 0
    while (list.cur != NULL)  
    {  
        if (strcmp(list.cur->element.user_name, username) == 0)  
            return 1;  
        list.cur = list.cur->next;
    }  
    return 0;  
} 
int checkAccount(singleList list, char ten[20], char pass[20]){ //check xem tai khoan va mat khau co dung khong
	// search all list to check username, password is correct or not
	// if correct, return 1
	// else return 0
	list.cur = list.root;
	while(list.cur != NULL){
		if ((strcmp(list.cur->element.user_name, ten) == 0) && (strcmp(list.cur->element.password, pass) == 0)){
			return 1;
		}
		list.cur = list.cur->next;
	}
	return 0;
}
int getStatus(singleList list, char ten[20]){
	list.cur = list.root;
	while(list.cur!=NULL){
		if (strcmp(list.cur->element.user_name, ten) == 0){
			return list.cur->element.status;
		}
		list.cur = list.cur->next;
	}
	return -1; //return -1 neu tai khoan khong ton tai
}


void writeToFile(char ten[20], char pass[20], int status){
	FILE *fp;
	fp = fopen("nguoidung.txt","a");
	fprintf(fp,"\n%s %s %d",ten, pass, status);
	fclose(fp);
} 
void setStatus(singleList list,char ten[20], int status){
	list.cur = list.root;
	while(list.cur != NULL){
		if (strcmp(list.cur->element.user_name, ten) == 0){
			list.cur->element.status = status;
			break;
		}
		list.cur = list.cur->next;
	}
	list.cur = list.root;
	// rewrite all list to file
	FILE *fp;
	fp = fopen("nguoidung.txt","w");
	while(list.cur!=NULL){
		if(list.cur->next == NULL){
			fprintf(fp,"%s %s %d",list.cur->element.user_name, list.cur->element.password, list.cur->element.status);
		}else{
			fprintf(fp,"%s %s %d\n",list.cur->element.user_name, list.cur->element.password, list.cur->element.status);
		}
		list.cur = list.cur->next;
	}
	fseek(fp, 0, SEEK_SET);
	fclose(fp);
}
void setPassword(singleList list,char ten[20], char pass[20]){
	list.cur = list.root;
	while(list.cur != NULL){
		if (strcmp(list.cur->element.user_name, ten) == 0){
			strcpy(list.cur->element.password, pass);
			break;
		}
		list.cur = list.cur->next;
	}
	list.cur = list.root;
	FILE *fp;
	fp = fopen("nguoidung.txt","w");
	fseek(fp, 0, SEEK_SET);
	while(list.cur!=NULL){
		if(list.cur->next == NULL){
			fprintf(fp,"%s %s %d",list.cur->element.user_name, list.cur->element.password, list.cur->element.status);
		}else{
			fprintf(fp,"%s %s %d\n",list.cur->element.user_name, list.cur->element.password, list.cur->element.status);
		}
		list.cur = list.cur->next;
	}
	fclose(fp);
}

//========================== END LINKED LIST================================//



int split(char * buffer, char * only_number,char * only_string){
	
	strcpy(only_string,buffer);
	int k=0;
	strcpy(only_number,buffer);
	int j=0;

	int m = 0;
	for(int i=0; i<100 ;i++){
		char ch = only_number[i];
		if (ch == '\0') break;
		if(ch >= '0' && ch <= '9'){
    	    only_number[j] = ch;
    	   	j++;
   		}
   		else if ((ch >= 'a' && ch <= 'z')||(ch == ' ')){
   			only_string[k] = ch;
   			k++;
   		}
   		else{
   			return 0;
   		}
   	}
   	only_number[j] = '\0'; 
	only_string[k] = '\0'; 
	return 1;
}

int main(int argc, char *argv[]) 
{
	fprintf(stderr, "default localhost ip: 127.0.0.1\n");
	FILE *fp;
	fp = fopen("nguoidung.txt","r");
	if (fp == NULL){
		printf("Failed\n");
		return 0;
	}
	singleList list;
	createSingleList(&list);
	elementtype element; 
	insertToList(&list,element);

	// catch wrong input
	if(argc==1){
		printf("Please input port number\n");
		return 0;
	}
	char *port_number = argv[1];
	int port = atoi(port_number);
	int opt = 1;
	int server_fd, new_socket; 
	struct sockaddr_in address;
	int addrlen = sizeof(address); 

	// Creating socket file descriptor 
	if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0) 
	{ 
		perror("socket failed"); 
		exit(EXIT_FAILURE); 
	} 
	
	// Forcefully attaching socket to the port 
	if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt))) 
	{ 
		perror("setsockopt"); 
		exit(EXIT_FAILURE); 
	} 
	address.sin_family = AF_INET; 
	address.sin_addr.s_addr = INADDR_ANY; 
	address.sin_port = htons( port ); 
	
	// Forcefully attaching socket to the port 
	if (bind(server_fd, (struct sockaddr *)&address, sizeof(address))<0) 
	{ 
		perror("bind failed"); 
		exit(EXIT_FAILURE); 
	} 
	if (listen(server_fd, 3) < 0) 
	{ 
		perror("listen"); 
		exit(EXIT_FAILURE); 
	} 
	if ((new_socket = accept(server_fd, (struct sockaddr *)&address, (socklen_t*)&addrlen))<0) 
	{ 
		perror("accept"); 
		exit(EXIT_FAILURE); 
	} 



	//============================Start to communicate with client=====================================
	//=================================================================================================
	int x, checked;
	char buffer1[100];
	char buffer2[100];
	char username[20];
	char password[20] = "";
	char checked_str[10];
	char only_string[20];
	char only_number[20];
	int status = 0;
	//status = 0 => cho nhap username
	//status = 1 => cho nhap password
	//status = 2 => da dang nhap
	int signed_in = 0;
	int valid_username = 0;
	while(1){
		while (signed_in != 1)
		{
		
			while (valid_username != 1)
			{
				x = read( new_socket , buffer1, 100);
				buffer1[x] = '\0';
				if (findInfo(list,buffer1) == 1){
					if (getStatus(list,buffer1) == 1){
						strcpy(username, buffer1);
						strcpy(buffer2, "username is OK");
						buffer2[strlen(buffer2)] = '\0';
						valid_username = 1;
						send(new_socket , buffer2, strlen(buffer2)  , 0 );
					}else if(getStatus(list,buffer1) == 0 || getStatus(list, buffer1)==2){
						send(new_socket , "0", 2 , 0 );
					}
				}else{
					send(new_socket , "0", 2 , 0 );
				}
			}


			checked = 0;
			while (checked != 1)
			{
				x = read( new_socket , buffer1, 100);
				if(strcmp("block", buffer1) == 0){
					setStatus(list, username, 0);
					valid_username = 0;
					signed_in = 0;
					break;
				}
				checked = checkAccount(list,username,buffer1);
				sprintf(checked_str, "%d", checked);
				send(new_socket , checked_str, strlen(checked_str) + 1  , 0 );
				if(checked == 1){
					signed_in = 1;
				}
			}
		}
				

		if(signed_in == 1){
			while (1)
			{
				x = read( new_socket , buffer1, 100);
				if (strcmp("bye", buffer1)==0)
				{
					signed_in = 0;
					valid_username = 0;
					checked = 0;
					break;
				}
				
				setPassword(list, username, buffer1);
				split(buffer1, only_number, only_string);
				printf("string: %s\n", only_string);
				printf("number: %s\n", only_number);
				char full_string[100];
				if(only_number[0] == '\0'){
					strcpy(full_string, only_string);
				}else
				{
					strcpy(full_string, only_number);
					strcat(full_string, only_string);
					full_string[strlen(full_string)] = '\0';
				}
				send(new_socket , full_string, strlen(full_string) + 1 , 0 );
			}
		}
	}
		
	return 0; 
} 
