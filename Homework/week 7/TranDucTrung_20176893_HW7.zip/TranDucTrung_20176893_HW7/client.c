#include <stdio.h> 
#include <sys/socket.h> 
#include <arpa/inet.h> 
#include <unistd.h> 
#include <string.h>
#include <stdlib.h>


int check_new_password(char new_password[100]){
	for(int i = 0; i < strlen(new_password); i++){
		if((new_password[i] < '0' || new_password[i] > '9') && 
		(new_password[i] < 'A' || new_password[i] > 'Z') && 
		(new_password[i] < 'a' || new_password[i] > 'z'))
		{ 
			return 0;
		}
		
	}
	return 1;
}


int main(int argc, char *argv[])
{
	if(argc!=3){
		printf("Please input IP address and port number\n");
		return 0;
	}
	char *ip_address = argv[1];
	int PORT = atoi(argv[2]);
	struct sockaddr_in serv_addr; 
	int sock = 0;

	// Try catch false when connecting
	if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
	{ 
		printf("\n Socket creation error \n"); 
		return -1; 
	} 

	serv_addr.sin_family = AF_INET; 
	serv_addr.sin_port = htons(PORT);
	serv_addr.sin_addr.s_addr = inet_addr(ip_address); 
	
	// Convert IPv4 and IPv6 addresses from text to binary form 
	if(inet_pton(AF_INET, ip_address, &serv_addr.sin_addr)<=0) 
	{ 
		printf("\nInvalid address/ Address not supported \n"); 
		return -1; 
	} 

	if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) 
	{ 
		printf("\nConnection Failed \n"); 
		return -1; 
	}

	
	
	// ============================Start to communicate with Server======================
	// ==================================================================================
	do {
		int g= 0;
		int signed_in = 0;
		char buffer[100];
		char message[100];
		char username[100];
		char password[100];
		char new_password[100];
		printf("Username: ");
		g = scanf("%[^\n]", message); 
		if (g == 0) break;
		getchar();
		strcpy(username, message);


		send(sock , message , strlen(message) + 1, 0 ); 
		
		// waiting for response 
		recv(sock, buffer, sizeof(buffer), 0);
		if(strcmp(buffer, "username is OK") == 0){
			int wrong_password_count = 0;
			do{
				printf("Instert password: ");
				fgets(password, 100, stdin);
				password[strlen(password)-1]='\0';
				send(sock , password , strlen(password) + 1 , 0 ); 
				recv(sock, buffer, sizeof(buffer), 0);
				if (atoi(buffer) == 1){
			 		printf("OK\n");
					signed_in = 1;
					break;
				}else
				{
					printf("Not OK\n");
					wrong_password_count++;
				}
				
			}while(wrong_password_count < 3);
			if (wrong_password_count == 3){
				send(sock , "block" , strlen("block") + 1 , 0 ); 
				printf("Account is blocked\n");
			}
		}else if(strcmp(buffer, "0") == 0)
		{
			printf("Account not ready\n");
		}
		puts("-------------------------------");
		if(signed_in == 1){
			puts("----------Signed in------------");
			do{
				printf("Enter \"bye\" to sign out. Another word to change password: ");
				fgets(new_password, 100, stdin);
				new_password[strlen(new_password)-1]='\0';
				if (check_new_password(new_password) != 0)
				{
					send(sock , new_password , strlen(new_password)+1 , 0 );
				} 
				if (strcmp("bye", new_password)== 0)
				{
					printf("Goodbye %s\n", username);
					puts("-------------------------------");
					signed_in = 0;
					break;
				}
				
				if (check_new_password(new_password) == 0)
				{
					printf("Error\n");
				}else
				{
					recv(sock, buffer, sizeof(buffer), 0);
					fprintf(stderr, buffer);
					fprintf(stderr, "\n");
				}
			}while (strcmp("bye", new_password) != 0);
		}
	}while(1);	
	// close the descriptor 
	close(sock); 
	return 0;
}