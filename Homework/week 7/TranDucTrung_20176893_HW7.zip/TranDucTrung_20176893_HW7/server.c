#include <unistd.h> 
#include <stdio.h> 
#include <sys/socket.h> 
#include <stdlib.h> 
#include <netinet/in.h> 
#include <string.h> 
#include<stdlib.h> 
#include <ctype.h>
#include <sys/types.h> 
#include <arpa/inet.h> 
#include <netdb.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>

typedef struct 
{
	char user_name[20];
	char password[20];
	int status;
}elementtype;
#include "linkedlist.h"

void sig_chld(int signo){
	pid_t pid;
	int stat;
	pid = waitpid(-1, &stat, WNOHANG);
	printf("child %d terminated\n", pid );
}
void insertToList(singleList *list,elementtype element){
	// make null the list
	deleteSingleList(list);
	FILE *fp;
	fp = fopen("nguoidung.txt","r");
	// counting the length of this file
	char c;
	int count =0;
	for (c = getc(fp); c != EOF; c = getc(fp)) 
	{
        if (c == '\n') // Increment count if this character is newline 
            count = count + 1; 
	}
	fclose(fp);
	// read the data to list 
	fp = fopen("nguoidung.txt","r");
	for(int i=0;i< count + 1;i++){
		fscanf(fp, "%s %s %d", element.user_name, element.password, &element.status);
		insertEnd(list,element);
	}  
	fclose(fp);
}
int findInfo(singleList list, char username[20])  
{  
    list.cur = list.root; // Initialize current  
    // search all list to find username
    // if existed , return 1
    // else return 0
    while (list.cur != NULL)  
    {  
        if (strcmp(list.cur->element.user_name, username) == 0)  
            return 1;  
        list.cur = list.cur->next;
    }  
    return 0;  
} 
int checkAccount(singleList list, char ten[20], char pass[20]){ //check xem tai khoan va mat khau co dung khong
	// search all list to check username, password is correct or not
	// if correct, return 1
	// else return 0
	list.cur = list.root;
	while(list.cur != NULL){
		if ((strcmp(list.cur->element.user_name, ten) == 0) && (strcmp(list.cur->element.password, pass) == 0)){
			return 1;
		}
		list.cur = list.cur->next;
	}
	return 0;
}
int getStatus(singleList list, char ten[20]){
	list.cur = list.root;
	while(list.cur!=NULL){
		if (strcmp(list.cur->element.user_name, ten) == 0){
			return list.cur->element.status;
		}
		list.cur = list.cur->next;
	}
	return -1; //return -1 neu tai khoan khong ton tai
}


void writeToFile(char ten[20], char pass[20], int status){
	FILE *fp;
	fp = fopen("nguoidung.txt","a");
	fprintf(fp,"\n%s %s %d",ten, pass, status);
	fclose(fp);
} 
void setStatus(singleList list,char ten[20], int status){
	list.cur = list.root;
	while(list.cur != NULL){
		if (strcmp(list.cur->element.user_name, ten) == 0){
			list.cur->element.status = status;
			break;
		}
		list.cur = list.cur->next;
	}
	list.cur = list.root;
	// rewrite all list to file
	FILE *fp;
	fp = fopen("nguoidung.txt","w");
	while(list.cur!=NULL){
		if(list.cur->next == NULL){
			fprintf(fp,"%s %s %d",list.cur->element.user_name, list.cur->element.password, list.cur->element.status);
		}else{
			fprintf(fp,"%s %s %d\n",list.cur->element.user_name, list.cur->element.password, list.cur->element.status);
		}
		list.cur = list.cur->next;
	}
	fseek(fp, 0, SEEK_SET);
	fclose(fp);
}
void setPassword(singleList list,char ten[20], char pass[20]){
	list.cur = list.root;
	while(list.cur != NULL){
		if (strcmp(list.cur->element.user_name, ten) == 0){
			strcpy(list.cur->element.password, pass);
			break;
		}
		list.cur = list.cur->next;
	}
	list.cur = list.root;
	FILE *fp;
	fp = fopen("nguoidung.txt","w");
	fseek(fp, 0, SEEK_SET);
	while(list.cur!=NULL){
		if(list.cur->next == NULL){
			fprintf(fp,"%s %s %d",list.cur->element.user_name, list.cur->element.password, list.cur->element.status);
		}else{
			fprintf(fp,"%s %s %d\n",list.cur->element.user_name, list.cur->element.password, list.cur->element.status);
		}
		list.cur = list.cur->next;
	}
	fclose(fp);
}

//========================== END LINKED LIST================================//



int split(char * buffer, char * only_number,char * only_string){
	
	strcpy(only_string,buffer);
	int k=0;
	strcpy(only_number,buffer);
	int j=0;

	int m = 0;
	for(int i=0; i<100 ;i++){
		char ch = only_number[i];
		if (ch == '\0') break;
		if(ch >= '0' && ch <= '9'){
    	    only_number[j] = ch;
    	   	j++;
   		}
   		else if ((ch >= 'a' && ch <= 'z')||(ch == ' ') || (ch >= 'A' && ch <= 'Z')){
   			only_string[k] = ch;
   			k++;
   		}
   		else{
   			return 0;
   		}
   	}
   	only_number[j] = '\0'; 
	only_string[k] = '\0'; 
	return 1;
}


int main(int argc, char *argv[]){

	// catch wrong input
	if (argc<2)
	{
		printf("Invalid Parameter\n");
		return 0;
	}
	// open fife
	// check if file existed
	FILE *fp;
	fp = fopen("nguoidung.txt","r");
	if (fp == NULL){
		printf("Failed\n");
		return 0;
	}
	singleList list;
	createSingleList(&list);
	elementtype element;
	printf("Local IP: 127.x.x.x\n"); 
	// int parent_fds[2], child_fds[2];

    // // read:[0] - write:[1]
    // if (pipe(parent_fds) != 0 || pipe(child_fds) != 0)  /* || not && */
    // {
    //     fprintf(stderr, "pipes failed!\n");
    //     return EXIT_FAILURE;
    // }

	// Create server - client
	int PORT = atoi(argv[1]);
	int listenfd, connfd;
	struct sockaddr_in server;
	struct sockaddr_in client;
	pid_t pid;
	int sin_size;
	if ((listenfd = socket(AF_INET, SOCK_STREAM,0 )) == 0){
		perror("Socket Failed");
		exit(EXIT_FAILURE);
	}
	bzero(&server, sizeof(server));
	server.sin_family = AF_INET; 
	server.sin_addr.s_addr = INADDR_ANY; 
	server.sin_port = htons( PORT ); 

	if(bind(listenfd, (struct sockaddr*)&server, sizeof(server))==-1){ 
		perror("\nError: ");
		return 0;
	}     

	if(listen(listenfd, 3) < 0){  
		perror("\nError: ");
		return 0;
	}
	signal(SIGCHLD, sig_chld);
	while(1){
		int x, checked;
		char buffer1[100];
		char buffer2[100];
		char username[20];
		char password[20] = "";
		char checked_str[10];
		char only_string[20];
		char only_number[20];
		int status = 0;
		//status = 0 => cho nhap username
		//status = 1 => cho nhap password
		//status = 2 => da dang nhap
		int signed_in = 0;
		int valid_username = 0;
		sin_size = sizeof(struct sockaddr_in);
		if ((connfd = accept(listenfd, (struct sockaddr *)&client, (socklen_t*)&sin_size))<0) { 
			perror("accept"); 
			exit(EXIT_FAILURE); 
		}

		



		pid = fork();
		if (pid == 0){
			insertToList(&list,element);
			printf("You got a connection from %s\n", inet_ntoa(client.sin_addr));
			printf("PID of this child process: %d\n", getpid());
			while (signed_in != 1)
			{
			
				while (valid_username != 1)
				{
					x = recv( connfd , buffer1, sizeof(buffer1), 0);
					buffer1[x] = '\0';
					if (findInfo(list,buffer1) == 1){
						if (getStatus(list,buffer1) == 1){
							strcpy(username, buffer1);
							strcpy(buffer2, "username is OK");
							buffer2[strlen(buffer2)] = '\0';
							valid_username = 1;
							send(connfd , buffer2, strlen(buffer2)  , 0 );
						}else if(getStatus(list,buffer1) == 0 || getStatus(list, buffer1)==2){
							send(connfd , "0", 2 , 0 );
						}
					}else{
						send(connfd , "0", 2 , 0 );
					}
				}


				checked = 0;
				while (checked != 1)
				{
					x = recv( connfd , buffer1, sizeof(buffer1), 0);
					if(strcmp("block", buffer1) == 0){
						setStatus(list, username, 0);
						valid_username = 0;
						signed_in = 0;
						break;
					}
					checked = checkAccount(list,username,buffer1);
					sprintf(checked_str, "%d", checked);
					send(connfd , checked_str, strlen(checked_str) + 1  , 0 );
					if(checked == 1){
						signed_in = 1;
					}
				}
			}
					

			if(signed_in == 1){
				while (1)
				{
					x = recv( connfd , buffer1, sizeof(buffer1), 0);
					if (strcmp("bye", buffer1)==0)
					{
						signed_in = 0;
						valid_username = 0;
						checked = 0;
						break;
					}
					
					setPassword(list, username, buffer1);
					split(buffer1, only_number, only_string);
					printf("string: %s\n", only_string);
					printf("number: %s\n", only_number);
					char full_string[100];
					if(only_number[0] == '\0'){
						strcpy(full_string, only_string);
					}else
					{
						strcpy(full_string, only_number);
						strcat(full_string, only_string);
						full_string[strlen(full_string)] = '\0';
					}
					send(connfd , full_string, strlen(full_string) + 1 , 0 );
				}
			}
			close(connfd);
			//exit(0);
		}
		close(connfd); 
	}
	//close(listenfd);	
	return 0;
}